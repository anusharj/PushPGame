var bg;
var invisibleGround;
var coin,coinSpin;
var player,player_moveL,player_moveR,player_idle,player_idleR;
var zombie,zombie_move;
var Gzombie,Gzombie_move,zombie_moveR,Gzombie_moveR;
var gunL1,gunR1;
var isleft=false;
var isright=false;
var bullet,bullet_ig,bullet_igR;
var bullet2Group,bulletGroup,zombiegroup,zombie2group,zombie3group,zombie4group;
var bullet;

function preload(){
  bg = loadImage("forest.png");
  player_idle = loadAnimation("Idle 1.png","Idle 2.png","Idle 3.png","Idle 4.png","Idle 5.png","Idle 6.png","Idle 7.png","Idle 8.png","Idle 9.png","Idle 10.png",);
  player_idleR = loadAnimation("Idle01.png","Idle02.png","Idle03.png","Idle04.png","Idle05.png","Idle06.png","Idle07.png","Idle08.png","Idle09.png","Idle010.png",);
  coinSpin = loadAnimation("Gold_21.png","Gold_22.png","Gold_23.png","Gold_24.png","Gold_25.png","Gold_26.png","Gold_27.png","Gold_28.png","Gold_29.png","Gold_30.png");
  player_moveL = loadAnimation("Run 1.png","Run 2.png","Run 3.png","Run4.png","Run 5.png","Run 6.png","Run 7.png","Run 8.png",);
  player_moveR = loadAnimation("Run 11.png","Run 12.png","Run 13.png","Run14.png","Run 15.png","Run 16.png","Run 17.png","Run 18.png",);
  zombie_move = loadAnimation("Walk1.png","Walk2.png","Walk3.png","Walk4.png","Walk5.png","Walk6.png","Walk7.png","Walk8.png","Walk9.png","Walk10.png",);
  Gzombie_move = loadAnimation("Walk01.png","Walk02.png","Walk03.png","Walk04.png","Walk05.png","Walk06.png","Walk07.png","Walk08.png","Walk09.png","Walk010.png",);
  zombie_moveL = loadAnimation("Walk1L.png","Walk2L.png","Walk3L.png","Walk4L.png","Walk5L.png","Walk6L.png","Walk7L.png","Walk8L.png","Walk9L.png","Walk10L.png",);
  Gzombie_moveL = loadAnimation("Walk01L.png","Walk02L.png","Walk03L.png","Walk04L.png","Walk05L.png","Walk06L.png","Walk07L.png","Walk08L.png","Walk09L.png","Walk010L.png",);
  gunL1 = loadAnimation("Shoot1.png","Shoot2.png","Shoot3.png");
  gunR1 = loadAnimation("Shoot01.png","Shoot02.png","Shoot03.png");
  bullet_ig = loadAnimation("bullet.png");
  bullet_igR = loadAnimation("bulletR.png");

}

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  player = createSprite(600,500,20,50);
  player.addAnimation("idle", player_idle);
  player.addAnimation("idleR", player_idleR);
  player.addAnimation("moving",player_moveR);
  player.addAnimation("movinG",player_moveL);
  player.addAnimation("gunl",gunL1);
  player.addAnimation("gunR",gunR1);


  player.scale = 0.3;

  bulletGroup = createGroup(); 
  bullet2Group = createGroup();
  zombiegroup = createGroup(); 
  zombie2group = createGroup(); 
  zombie3group = createGroup(); 
  zombie4group = createGroup(); 

  coin = createSprite(1380,40,20,50);
  coin.addAnimation("running", coinSpin);
  coin.scale = 0.1;

  invisibleGround = createSprite(500,650,10000,50);
  invisibleGround.visible = false;  


}

function draw() {
  background(bg);
  drawSprites();
  spawnZombie()
  spawnZombie2()
  spawnZombie3()
  spawnZombie4()
  //bullet.x = player.x;

  
 if(bulletGroup.isTouching(zombiegroup)){
  
    for(var i=0;i<zombiegroup.length;i++){     
        
     if(zombiegroup[i].isTouching(bulletGroup)){
          zombiegroup[i].destroy()
          bulletGroup.destroyEach()
         
          } 
    
    }
  
 // zombiegroup.destroyEach();
 // bulletGroup.destroyEach();
 }
 if(bulletGroup.isTouching(zombie2group)){
  for(var i=0;i<zombie2group.length;i++){     
        
    if(zombie2group[i].isTouching(bulletGroup)){
      zombie2group[i].destroy()
         bulletGroup.destroyEach()
        
         } 
   
   }
  //zombie2group.destroyEach();
 // bulletGroup.destroyEach();
 }
 if(bulletGroup.isTouching(zombie3group)){
  for(var i=0;i<zombie3group.length;i++){     
        
    if(zombie3group[i].isTouching(bulletGroup)){
      zombie3group[i].destroy()
         bulletGroup.destroyEach()
        
         } 
   
   }
  //zombie3group.destroyEach();
  //bulletGroup.destroyEach();
 }
 if(bulletGroup.isTouching(zombie4group)){
  for(var i=0;i<zombie4group.length;i++){     
        
    if(zombie4group[i].isTouching(bulletGroup)){
      zombie4group[i].destroy()
         bulletGroup.destroyEach()
        
         } 
   
   }
 // zombie4group.destroyEach();
 // bulletGroup.destroyEach();
 }
 if(bullet2Group.isTouching(zombiegroup)){
  for(var i=0;i<zombiegroup.length;i++){     
        
    if(zombiegroup[i].isTouching(bullet2Group)){
      zombiegroup[i].destroy()
      bullet2Group.destroyEach()
        
         } 
   
   }
 // zombiegroup.destroyEach();
 // bullet2Group.destroyEach();
 }
 if(bullet2Group.isTouching(zombie2group)){
  for(var i=0;i<zombie2group.length;i++){     
        
    if(zombie2group[i].isTouching(bullet2Group)){
      zombie2group[i].destroy()
      bullet2Group.destroyEach()
        
         } 
   
   }
  //zombie2group.destroyEach();
  //bullet2Group.destroyEach();
 }
 if(bullet2Group.isTouching(zombie3group)){
  for(var i=0;i<zombie2group.length;i++){     
        
    if(zombie3group[i].isTouching(bullet2Group)){
      zombie3group[i].destroy()
      bullet2Group.destroyEach()
        
         } 
   
   }
 // zombie3group.destroyEach();
 // bullet2Group.destroyEach();
 }
 if(bullet2Group.isTouching(zombie4group)){
  for(var i=0;i<zombie4group.length;i++){     
        
    if(zombie4group[i].isTouching(bullet2Group)){
      zombie4group[i].destroy()
      bullet2Group.destroyEach()
        
         } 
   
   }
  ///zombie4group.destroyEach();
 // bullet2Group.destroyEach();
 }
    
}
function keyPressed(){
  if(keyCode==37){
  player.changeAnimation("moving");
  player.velocityX = - 5;
  isleft=true
  isright=false
  }
  if(keyCode==39){
  player.changeAnimation("movinG");
  player.velocityX =+ 5;
  isright=true
  isleft=false
  }
  if(keyCode==32){
    if(isleft){
    player.changeAnimation("gunR");
    var bullet=createSprite(player.x,player.y,10,10)
    bullet.addAnimation("bulletR",bullet_igR);
    bullet.scale=0.019;
    bullet.velocityX=-5
    handlebullet(bullet);
    bulletGroup.add(bullet);
    bullet.debug = true
    }
    if(isright){
    player.changeAnimation("gunl")
    var bullet2 =createSprite(player.x,player.y,10,10)
    bullet2.addAnimation("bulletL",bullet_ig);
    bullet2.scale=0.019;
    bullet2.velocityX=5;
    handlebullet2(bullet2);
    bullet2Group.add(bullet2);
    bullet2.debug = true
    }
  }
}
function keyReleased(){
  if(keyCode ==37){
    player.changeAnimation("idleR");
    player.velocityX = 0
  }
  if(keyCode ==39){
    player.changeAnimation("idle");
    player.velocityX = 0
  }
  if(keyCode==32){
    player.changeAnimation("idle");
    }
}
function spawnZombie(){
  if (frameCount % 120 === 0){
    var zombie = createSprite(1,500,10,40);
    zombie.addAnimation("zombieB",zombie_move);
    zombie.velocityX = 2;
     zombie.scale = 0.3;
     zombiegroup.add(zombie);
  }
}
 function spawnZombie2(){
  if (frameCount % 120 === 0){
    var zombie2 = createSprite(1500,500,10,40);
    zombie2.addAnimation("zombieBL",zombie_moveL);
    zombie2.velocityX = -2;
     zombie2.scale = 0.3;
     zombie2group.add(zombie2);
  }
}
function spawnZombie3(){
  if (frameCount % 90 === 0){
    var zombie3 = createSprite(1,500,10,40);
    zombie3.addAnimation("zombieG",Gzombie_move);
    zombie3.velocityX = 2;
    zombie3.scale = 0.3;
    zombie3group.add(zombie3);
  }
}
function spawnZombie4(){
  if (frameCount % 90 === 0){
    var zombie4 = createSprite(1500,500,10,40);
    zombie4.addAnimation("zombieGL",Gzombie_moveL);
    zombie4.velocityX = -2;
    zombie4.scale = 0.3;
    zombie4group.add(zombie4);
  }
}
function handlebullet(bullet){
  bullet.isTouching(zombiegroup, function(collector, collected){
  collected.remove();
  })
  bullet.isTouching(zombie3group, function(collector, collected){
    collected.remove();
    })
    bullet.isTouching(zombie2group, function(collector, collected){
      collected.remove();
      })
      bullet.isTouching(zombie4group, function(collector, collected){
        collected.remove();
        })
}
function handlebullet2(bullet2){
  bullet2.isTouching(zombie2group, function(collector, collected){
  collected.remove();
  })
  bullet2.isTouching(zombie4group, function(collector, collected){
    collected.remove();
    })
    bullet2.isTouching(zombiegroup, function(collector, collected){
      collected.remove();
      })
      bullet2.isTouching(zombie3group, function(collector, collected){
        collected.remove();
        })
}
